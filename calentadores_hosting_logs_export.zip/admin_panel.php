<?php
include('config.php');
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['usuario'] !== 'admin') {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['añadir'])) {
        $nuevo_user = $conn->real_escape_string($_POST['nombre_usuario']);
        $nueva_clave = $conn->real_escape_string($_POST['clave']);
        $tipo = $conn->real_escape_string($_POST['tipo_usuario']);
        $sql = "INSERT INTO usuarios (nombre_usuario, clave, tipo_usuario) VALUES 
            ('{$nuevo_user}', '{$nueva_clave}', '{$tipo}')";
        $conn->query($sql);
    } elseif (isset($_POST['eliminar'])) {
        $id = intval($_POST['id_usuario']);
        $conn->query("DELETE FROM usuarios WHERE id = {$id}");
    } elseif (isset($_POST['editar'])) {
        $id = intval($_POST['id_usuario']);
        $nueva_clave = $conn->real_escape_string($_POST['nueva_clave']);
        $nuevo_tipo = $conn->real_escape_string($_POST['nuevo_tipo']);
        $sql = "UPDATE usuarios SET clave = '{$nueva_clave}', tipo_usuario = '{$nuevo_tipo}' WHERE id = {$id}";
        $conn->query($sql);
    }
    $accion = '';
    if (isset($_POST['añadir'])) {
        $accion = "Añadió usuario {$nuevo_user} con tipo {$tipo}";
    } elseif (isset($_POST['eliminar'])) {
        $accion = "Eliminó usuario ID {$id}";
    } elseif (isset($_POST['editar'])) {
        $accion = "Editó usuario ID {$id}, tipo a {$nuevo_tipo}";
    }
    $admin = $_SESSION['usuario'];
    $conn->query("INSERT INTO logs (usuario, accion) VALUES ('$admin', '$accion')");
    header('Location: admin_panel.php');
    exit();
}

$result = $conn->query("SELECT id, nombre_usuario, tipo_usuario FROM usuarios");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel de Administrador</title>
    <style>
      body { font-family: Arial, sans-serif; background-color: #f4f7f9; padding: 20px; }
      h2 { color: #2c3e50; }
      table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
      th, td { padding: 10px; border: 1px solid #ddd; text-align: left; }
      th { background-color: #27ae60; color: #fff; }
      form { margin-bottom: 20px; background: #fff; padding: 15px; border-radius: 5px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
      input[type=text], select { width: calc(33% - 12px); padding: 8px; margin-right: 10px; margin-bottom: 10px; border: 1px solid #ccc; border-radius: 4px; }
      input[type=submit] { background-color: #27ae60; color: white; border: none; padding: 8px 12px; border-radius: 4px; cursor: pointer; }
      input[type=submit]:hover { background-color: #219150; }
      .delete-btn { background-color: #c0392b; }
      .delete-btn:hover { background-color: #a93226; }
      .edit-btn { background-color: #2980b9; }
      .edit-btn:hover { background-color: #2471a3; }
    </style>
</head>
<body>
    <h2>Gestión de Usuarios</h2>
    <form method="post">
        <input type="text" name="nombre_usuario" placeholder="Nombre de usuario" required>
        <input type="text" name="clave" placeholder="Contraseña" required>
        <select name="tipo_usuario" required>
            <option value="admin">Administrador</option>
            <option value="cliente">Cliente</option>
        </select>
        <input type="submit" name="añadir" value="Añadir Usuario">
    </form>
    <table>
        <tr>
            <th>ID</th>
            <th>Usuario</th>
            <th>Tipo</th>
            <th colspan="2">Acciones</th>
        </tr>
        <?php while($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['id']; ?></td>
            <td><?= htmlspecialchars($row['nombre_usuario']); ?></td>
            <td><?= $row['tipo_usuario']; ?></td>
            <td>
                <?php if ($row['nombre_usuario'] !== 'admin'): ?>
                <form method="post" style="display:inline;">
                    <input type="hidden" name="id_usuario" value="<?= $row['id']; ?>">
                    <input type="submit" name="eliminar" value="Eliminar" class="delete-btn">
                </form>
                <?php endif; ?>
            </td>
            <td>
                <form method="post" style="display:inline;">
                    <input type="hidden" name="id_usuario" value="<?= $row['id']; ?>">
                    <input type="text" name="nueva_clave" placeholder="Nueva clave" required>
                    <select name="nuevo_tipo" required>
                        <option value="admin">Administrador</option>
                        <option value="cliente">Cliente</option>
                    </select>
                    <input type="submit" name="editar" value="Editar" class="edit-btn">
                </form>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
    <a href="calentadores.php">Volver al sitio</a>
</body>
</html>

<br><hr>
<h2>Exportar Actividad</h2>
<form action="export_logs.php" method="post">
    <input type="submit" name="exportar" value="Exportar a Excel">
</form>
