
CREATE DATABASE IF NOT EXISTS calentadores;
USE calentadores;

CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre_usuario VARCHAR(50) NOT NULL UNIQUE,
    clave VARCHAR(255) NOT NULL,
    tipo_usuario ENUM('admin', 'cliente') NOT NULL
);

-- Insertar usuarios
INSERT INTO usuarios (nombre_usuario, clave, tipo_usuario) VALUES
('admin', 'admin123', 'admin'),
('cliente', 'cliente123', 'cliente');

-- Tabla de logs de actividad
CREATE TABLE IF NOT EXISTS logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario VARCHAR(50),
    accion TEXT,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
