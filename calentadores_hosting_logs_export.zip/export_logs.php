<?php
include('config.php');
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=logs_actividad.xls");
echo "ID	Usuario	Acción	Fecha\n";

$result = $conn->query("SELECT * FROM logs ORDER BY fecha DESC");
while($row = $result->fetch_assoc()) {
    echo "{$row['id']}	{$row['usuario']}	{$row['accion']}	{$row['fecha']}\n";
}
?>
