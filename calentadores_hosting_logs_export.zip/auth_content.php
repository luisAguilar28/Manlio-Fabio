<?php include('config.php');

<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = $_POST['usuario'];
    $clave = $_POST['clave'];
    if (($usuario == "admin" && $clave == "admin123") || ($usuario == "cliente" && $clave == "cliente123")) {
        $_SESSION['usuario'] = $usuario;
    } else {
        echo "<script>alert('Credenciales incorrectas');window.location='login.php';</script>";
        exit();
    }
}
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}
?>
